#ifndef __LIBRARY__H__
#define __LIBRARY__H__
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <time.h>
#include <utility>
#include <cstring>
#include <bits/stdc++.h>
#include <stdio.h>
#include <ctype.h>
using namespace std;


#endif