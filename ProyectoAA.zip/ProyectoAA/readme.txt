Los colores usados son:
    N: Naranja
    A: Amarillo

    V: Verde
    R: Rojo
    
    B: Blue-Azul
    M: AguaMarian(Mar)
    
    P: Purple
    O: Rosa
    
    T: Marron


Los juegos se ven representados en un fichero de texto: "mapas.txt"
donde cada linea del fichero representa un juego correspondiente.
La nomenclatura en cada linea de texto es la siguiente:

Primer caracter: Representa el tamaño del tablero, siendo un numero
se ve representado como un entero

Posterior al primer caracter, la información se ve agrupada en grupos de 5 caracteres.
tal de la siguiente forma

[Caracter: Color][Entero: Fila 1][Entero: Columna 1][Entero: Fila 2][Entero: Columna 2]

Esto se repite N colores en el mapa del juego

COMPILACION Y EJECUCION:

Para ejecutar el programa ingresar estos dos comandos:

    1. g++ -o main flowFree.cpp
    2. ./main





